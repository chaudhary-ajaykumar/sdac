package operation;

import java.util.List;
import model.Order_pojo;
import model.Product_pojo;

public interface Order_operations {
    List<Product_pojo> getAllProducts();

    List<Order_pojo> getAllOrders();

    List<Order_pojo> getAllOrders(String sellerPortId);

    String placeOrder(int productId, String consumerPortId, int quantity, String sellerPortId, String consumerLocation);

    String updateOrderQuantity(int orderId, int newQuantity);

    String updateOrderConsumer(int orderId, String newConsumerPortId);

    String updateConsumerLocation(String consumerPortId, String newLocation);

    String deleteOrder(int orderId);

    Order_pojo getOrderById(int orderId);

    String incrementProductQuantity(int productId, int quantity);

    String updateOrderQuantityWithInventory(int orderId, int newQuantity);

    List<Product_pojo> getProductsPaginated(int offset, int limit);

    int getProductsCount();

    List<Order_pojo> getOrdersByConsumer(String consumerPortId);

    // Remove OrderStatusPojo, use Order_pojo for status
    Order_pojo getOrderStatus(int orderId);

    String updateOrderFlag(int orderId, String stage);

    // For seller orders pagination
    List<Order_pojo> getSellerOrdersPaginated(String sellerPortId, int offset, int limit);

    int getSellerOrdersCount(String sellerPortId);

    // For consumer orders pagination
    List<Order_pojo> getConsumerOrdersPaginated(String consumerPortId, int offset, int limit);

    int getConsumerOrdersCount(String consumerPortId);
}
