package operation;

public interface EditProfileOperations {
    String editProfile(
        String portId,
        String role,
        String newPassword,
        String newLocation,
        boolean updatePassword,
        boolean updateLocation,
        boolean deleteAccount
    );
}
