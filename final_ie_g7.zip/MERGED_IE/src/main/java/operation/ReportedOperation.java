package operation;

import java.util.List;
import model.ReportedModel;

public interface ReportedOperation {
    // Consumer
    boolean reportIssue(ReportedModel report);

    List<ReportedModel> getReportsByConsumer(String consumerPortId);

    // Seller
    List<ReportedModel> getReportsBySeller(String sellerPortId);

    boolean markReportSolved(int reportId, String sellerPortId);
}
