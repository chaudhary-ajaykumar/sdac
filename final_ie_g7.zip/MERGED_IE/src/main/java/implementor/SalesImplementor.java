package implementor;

import db_config.GetConnection;
import model.SalesPojo;
import operation.SalesOperations;

import java.sql.*;
import java.util.*;

public class SalesImplementor implements SalesOperations {

    @Override
    public List<SalesPojo> getMonthlySales(String sellerId, int year) {
        List<SalesPojo> list = new ArrayList<>();
        try (Connection con = GetConnection.getConnection()) {
            CallableStatement cs = con.prepareCall("{call seller_monthly_sales(?, ?)}");
            cs.setString(1, sellerId);
            cs.setInt(2, year);
            ResultSet rs = cs.executeQuery();
            while (rs.next()) {
                list.add(new SalesPojo(rs.getString(1), rs.getDouble(2)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<SalesPojo> getAnnualSales(String sellerId) {
        List<SalesPojo> list = new ArrayList<>();
        try (Connection con = GetConnection.getConnection()) {
            CallableStatement cs = con.prepareCall("{call seller_annual_sales(?)}");
            cs.setString(1, sellerId);
            ResultSet rs = cs.executeQuery();
            while (rs.next()) {
                list.add(new SalesPojo(rs.getString(1), rs.getDouble(2)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public double getTotalRevenue(String sellerId) {
        double revenue = 0;
        try (Connection con = GetConnection.getConnection()) {
            CallableStatement cs = con.prepareCall("{call seller_total_revenue(?)}");
            cs.setString(1, sellerId);
            ResultSet rs = cs.executeQuery();
            if (rs.next()) {
                revenue = rs.getDouble(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return revenue;
    }

    @Override
    public int getTotalOrders(String sellerId) {
        int total = 0;
        try (Connection con = GetConnection.getConnection()) {
            PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM orders WHERE seller_port_id = ?");
            ps.setString(1, sellerId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                total = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return total;
    }

    @Override
    public int getPendingOrders(String sellerId) {
        int pending = 0;
        try (Connection con = GetConnection.getConnection()) {
            PreparedStatement ps = con
                    .prepareStatement("SELECT COUNT(*) FROM orders WHERE seller_port_id = ? AND delivered = 0");
            ps.setString(1, sellerId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                pending = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return pending;
    }
}
