package model;

import java.util.Date;

public class ReportedModel {
    private int reportId;
    private int productId;
    private String productName;
    private String issueType;
    private String status;
    private String actionTaken;
    private Date reportDate;
    private String sellerPortId;
    private String consumerPortId;
    private int orderId;

    public int getReportId() {
        return reportId;
    }

    public void setReportId(int reportId) {
        this.reportId = reportId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getIssueType() {
        return issueType;
    }

    public void setIssueType(String issueType) {
        this.issueType = issueType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getActionTaken() {
        return actionTaken;
    }

    public void setActionTaken(String actionTaken) {
        this.actionTaken = actionTaken;
    }

    public Date getReportDate() {
        return reportDate;
    }

    public void setReportDate(Date reportDate) {
        this.reportDate = reportDate;
    }

    public String getSellerPortId() {
        return sellerPortId;
    }

    public void setSellerPortId(String sellerPortId) {
        this.sellerPortId = sellerPortId;
    }

    public String getConsumerPortId() {
        return consumerPortId;
    }

    public void setConsumerPortId(String consumerPortId) {
        this.consumerPortId = consumerPortId;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }
}
