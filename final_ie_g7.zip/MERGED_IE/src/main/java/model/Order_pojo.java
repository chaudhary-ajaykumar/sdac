package model;

import java.sql.Date;

public class Order_pojo {

    private int orderId;
    private int productId;
    private String productName;
    private String consumerPortId;
    private String sellerPortId;
    private int quantity;
    private Date orderDate;
    private boolean orderPlaced;
    private boolean shipped;
    private boolean outForDelivery;
    private boolean delivered;
    private String consumerPortLocation;
    private String status;
    private Double price; // Add this field

    public Order_pojo() {
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getConsumerPortId() {
        return consumerPortId;
    }

    public void setConsumerPortId(String consumerPortId) {
        this.consumerPortId = consumerPortId;
    }

    public String getSellerPortId() {
        return sellerPortId;
    }

    public void setSellerPortId(String sellerPortId) {
        this.sellerPortId = sellerPortId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public boolean isOrderPlaced() {
        return orderPlaced;
    }

    public void setOrderPlaced(boolean orderPlaced) {
        this.orderPlaced = orderPlaced;
    }

    public boolean isShipped() {
        return shipped;
    }

    public void setShipped(boolean shipped) {
        this.shipped = shipped;
    }

    public boolean isOutForDelivery() {
        return outForDelivery;
    }

    public void setOutForDelivery(boolean outForDelivery) {
        this.outForDelivery = outForDelivery;
    }

    public boolean isDelivered() {
        return delivered;
    }

    public void setDelivered(boolean delivered) {
        this.delivered = delivered;
    }

    public String getConsumerPortLocation() {
        return consumerPortLocation;
    }

    public void setConsumerPortLocation(String consumerPortLocation) {
        this.consumerPortLocation = consumerPortLocation;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }
}
