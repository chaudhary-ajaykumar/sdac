package model;

public class SalesPojo {
    private String period;
    private double revenue;

    public SalesPojo(String period, double revenue) {
        this.period = period;
        this.revenue = revenue;
    }

    public String getPeriod() {
        return period;
    }

    public double getRevenue() {
        return revenue;
    }
}
