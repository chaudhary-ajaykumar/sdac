package controller;

import implementor.ReportedImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import model.ReportedModel;

import java.io.IOException;
import java.util.List;

@WebServlet("/reported")
public class ReportedServlet extends HttpServlet {
    private final ReportedImpl reportedOps = new ReportedImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String role = (String) session.getAttribute("role");
        String portId = (String) session.getAttribute("port_id");

        // Prefill for report form if params present
        String orderId = request.getParameter("order_id");
        String productId = request.getParameter("product_id");
        String sellerId = request.getParameter("seller_id");
        if (orderId != null)
            request.setAttribute("order_id", orderId);
        if (productId != null)
            request.setAttribute("product_id", productId);
        if (sellerId != null)
            request.setAttribute("seller_id", sellerId);

        if (role == null || portId == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        if ("Seller".equalsIgnoreCase(role)) {
            // Seller: show all reports for their products
            List<ReportedModel> reports = reportedOps.getReportsBySeller(portId);
            request.setAttribute("reports", reports);
            request.getRequestDispatcher("manage_reported_products.jsp").forward(request, response);
        } else {
            // Consumer: show their own reports
            List<ReportedModel> reports = reportedOps.getReportsByConsumer(portId);
            request.setAttribute("reports", reports);
            request.getRequestDispatcher("report_issues.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        ReportedImpl dao = new ReportedImpl();

        if ("solve".equals(action)) {
            int reportId = Integer.parseInt(request.getParameter("report_id"));
            String sellerId = request.getParameter("seller_id");
            dao.markReportSolved(reportId, sellerId);
            response.sendRedirect("reported");
        } else {
            // Default: Submit new report
            ReportedModel model = new ReportedModel();
            model.setOrderId(Integer.parseInt(request.getParameter("order_id")));
            model.setProductId(Integer.parseInt(request.getParameter("product_id")));
            model.setConsumerPortId(request.getParameter("consumer_id"));
            model.setSellerPortId(request.getParameter("seller_id"));
            model.setIssueType(request.getParameter("issue_type"));
            dao.reportIssue(model);
            response.sendRedirect("order_dashboard.jsp");
        }
    }
}
