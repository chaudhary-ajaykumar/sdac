package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import implementor.Order_Implementor;
import model.Order_pojo;
import model.Product_pojo;
import operation.Order_operations;

import java.io.IOException;
import java.util.List;

@WebServlet("/order")
public class OrderServlet extends HttpServlet {
    private final Order_operations ops = new Order_Implementor();

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if (action == null) {
            response.getWriter().println("Error: action parameter is required.");
            return;
        }

        if ("viewSellerOrders".equals(action)) {
            HttpSession session = request.getSession();
            String sellerPortId = (String) session.getAttribute("port_id");
            String role = (String) session.getAttribute("role");
            System.out.println("Seller ID in session: " + sellerPortId + ", role: " + role); // Debug print
            if (sellerPortId == null || sellerPortId.trim().isEmpty()) {
                request.setAttribute("message", "Please login as seller to view orders.");
                request.getRequestDispatcher("login.jsp").forward(request, response);
                return;
            }
            System.out.println("Seller Port ID: " + sellerPortId);
            int page = 1;
            int recordsPerPage = 10;
            if (request.getParameter("page") != null) {
                page = Integer.parseInt(request.getParameter("page"));
            }
            int offset = (page - 1) * recordsPerPage;
            List<Order_pojo> sellerOrders = ops.getSellerOrdersPaginated(sellerPortId, offset, recordsPerPage);
            System.out.println("Seller Orders fetched: " + sellerOrders.size()); // Debug print
            int totalRecords = ops.getSellerOrdersCount(sellerPortId);
            int totalPages = (int) Math.ceil(totalRecords * 1.0 / recordsPerPage);

            request.setAttribute("orders", sellerOrders);
            request.setAttribute("currentPage", page);
            request.setAttribute("totalPages", totalPages);
            request.getRequestDispatcher("track_product.jsp").forward(request, response);
            return;
        }

        switch (action) {
            case "viewProducts":
                int page = 1;
                int recordsPerPage = 10;
                if (request.getParameter("page") != null) {
                    page = Integer.parseInt(request.getParameter("page"));
                }
                int offset = (page - 1) * recordsPerPage;
                List<Product_pojo> products = ops.getProductsPaginated(offset, recordsPerPage);
                int totalRecords = ops.getProductsCount();
                int totalPages = (int) Math.ceil(totalRecords * 1.0 / recordsPerPage);

                request.setAttribute("products", products);
                request.setAttribute("currentPage", page);
                request.setAttribute("totalPages", totalPages);
                request.getRequestDispatcher("viewProducts.jsp").forward(request, response);
                break;

            case "viewOrders":
                HttpSession session = request.getSession();
                String consumerPortId = (String) session.getAttribute("port_id");
                System.out.println("Consumer ID in session: " + consumerPortId); // Debug print
                if (consumerPortId == null || consumerPortId.trim().isEmpty()) {
                    request.setAttribute("message", "Please login to view your orders.");
                    request.getRequestDispatcher("login.jsp").forward(request, response);
                    return;
                }
                int cPage = 1;
                int cRecordsPerPage = 10;
                if (request.getParameter("page") != null) {
                    cPage = Integer.parseInt(request.getParameter("page"));
                }
                int cOffset = (cPage - 1) * cRecordsPerPage;
                List<Order_pojo> myOrders = ops.getConsumerOrdersPaginated(consumerPortId, cOffset, cRecordsPerPage);
                System.out.println("Orders fetched: " + myOrders.size()); // Debug print
                int cTotalRecords = ops.getConsumerOrdersCount(consumerPortId);
                int cTotalPages = (int) Math.ceil(cTotalRecords * 1.0 / cRecordsPerPage);

                request.setAttribute("orders", myOrders);
                request.setAttribute("currentPage", cPage);
                request.setAttribute("totalPages", cTotalPages);
                request.getRequestDispatcher("order_dashboard.jsp").forward(request, response);
                break;

            default:
                response.getWriter().println("Invalid action.");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        String message = "";

        if (action == null) {
            message = "Error: action parameter is required.";
        } else {
            switch (action) {
                case "placeOrder":
                    int productId = Integer.parseInt(request.getParameter("productId"));
                    String consumerPortId = request.getParameter("consumerPortId");
                    String consumerLocation = request.getParameter("consumerLocation");
                    int quantity = Integer.parseInt(request.getParameter("quantity"));
                    String sellerPortId = request.getParameter("sellerPortId");

                    message = ops.placeOrder(productId, consumerPortId, quantity, sellerPortId, consumerLocation);
                    // After placing order, reload products page with message
                    int page = 1;
                    int recordsPerPage = 10;
                    if (request.getParameter("page") != null) {
                        page = Integer.parseInt(request.getParameter("page"));
                    }
                    int offset = (page - 1) * recordsPerPage;
                    List<Product_pojo> products = ops.getProductsPaginated(offset, recordsPerPage);
                    int totalRecords = ops.getProductsCount();
                    int totalPages = (int) Math.ceil(totalRecords * 1.0 / recordsPerPage);

                    request.setAttribute("message", message);
                    request.setAttribute("products", products);
                    request.setAttribute("currentPage", page);
                    request.setAttribute("totalPages", totalPages);
                    request.getRequestDispatcher("viewProducts.jsp").forward(request, response);
                    return;

                case "updateQuantity":
                    int orderIdQ = Integer.parseInt(request.getParameter("orderId"));
                    int newQuantity = Integer.parseInt(request.getParameter("newQuantity"));
                    message = ops.updateOrderQuantityWithInventory(orderIdQ, newQuantity);
                    break;

                case "updateConsumer":
                    int orderIdC = Integer.parseInt(request.getParameter("orderId"));
                    String newConsumerPortId = request.getParameter("newConsumerPortId");
                    message = ops.updateOrderConsumer(orderIdC, newConsumerPortId);
                    break;

                case "updateLocation":
                    String consumerPortIdL = request.getParameter("consumerPortId");
                    String newLocation = request.getParameter("newLocation");
                    message = ops.updateConsumerLocation(consumerPortIdL, newLocation);
                    break;

                case "updateAll":
                    int orderId = Integer.parseInt(request.getParameter("orderId"));
                    int newQty = Integer.parseInt(request.getParameter("newQuantity"));
                    String newConsumer = request.getParameter("newConsumerPortId");
                    String newLoc = request.getParameter("newLocation");
                    String oldConsumer = request.getParameter("consumerPortId");

                    message = ops.updateOrderQuantityWithInventory(orderId, newQty);
                    ops.updateOrderConsumer(orderId, newConsumer);
                    ops.updateConsumerLocation(oldConsumer, newLoc);
                    break;

                case "deleteOrder":
                    int orderIdD = Integer.parseInt(request.getParameter("orderId"));
                    message = ops.deleteOrder(orderIdD);
                    break;

                case "updateStatus":
                    int updOrderId = Integer.parseInt(request.getParameter("orderId"));
                    String stage = request.getParameter("stage");
                    String msg = ops.updateOrderFlag(updOrderId, stage);
                    request.setAttribute("message", msg);
                    // After update, reload seller orders
                    response.sendRedirect("order?action=viewSellerOrders");
                    return;

                default:
                    message = "Invalid action.";
            }
        }

        if ("deleteOrder".equals(action) || "updateQuantity".equals(action)) {
            request.getSession().setAttribute("toastMessage", message);
            response.sendRedirect("order?action=viewOrders");
            return;
        }

        List<Product_pojo> products = ops.getAllProducts();
        List<Order_pojo> orders = ops.getAllOrders();
        request.setAttribute("message", message);
        request.setAttribute("products", products);
        request.setAttribute("orders", orders);

        request.getRequestDispatcher("viewProducts.jsp").forward(request, response);
    }
}
