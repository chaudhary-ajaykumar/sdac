package implementor;

import db_config.GetConnection;
import model.ReportedModel;
import operation.ReportedOperation;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReportedImpl implements ReportedOperation {
    @Override
    public boolean reportIssue(ReportedModel report) {
        try (Connection con = GetConnection.getConnection();
                CallableStatement cs = con.prepareCall("{call add_reported_product(?,?,?,?,?)}")) {
            cs.setInt(1, report.getOrderId());
            cs.setString(2, report.getConsumerPortId());
            cs.setString(3, report.getSellerPortId());
            cs.setInt(4, report.getProductId());
            cs.setString(5, report.getIssueType());
            cs.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<ReportedModel> getReportsByConsumer(String consumerPortId) {
        List<ReportedModel> list = new ArrayList<>();
        String sql = "CALL get_reported_issues_by_consumer(?)";
        try (Connection con = GetConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, consumerPortId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ReportedModel r = new ReportedModel();
                r.setReportId(rs.getInt("report_id"));
                r.setProductId(rs.getInt("product_id"));
                r.setIssueType(rs.getString("issue_type"));
                r.setStatus(rs.getString("status"));
                r.setActionTaken(rs.getString("action_taken"));
                r.setReportDate(rs.getTimestamp("report_date"));
                r.setSellerPortId(rs.getString("seller_port_id"));
                list.add(r);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<ReportedModel> getReportsBySeller(String sellerPortId) {
        List<ReportedModel> list = new ArrayList<>();
        String sql = "CALL get_reports_by_seller(?)";
        try (Connection con = GetConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, sellerPortId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ReportedModel r = new ReportedModel();
                r.setReportId(rs.getInt("report_id"));
                r.setProductId(rs.getInt("product_id"));
                r.setProductName(rs.getString("product_name"));
                r.setIssueType(rs.getString("issue_type"));
                r.setStatus(rs.getString("status"));
                r.setActionTaken(rs.getString("action_taken"));
                r.setReportDate(rs.getTimestamp("report_date"));
                r.setConsumerPortId(rs.getString("consumer_port_id"));
                list.add(r);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public boolean markReportSolved(int reportId, String sellerPortId) {
        String sql = "CALL update_report_status(?, ?)";
        try (Connection con = GetConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, reportId);
            ps.setString(2, sellerPortId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
