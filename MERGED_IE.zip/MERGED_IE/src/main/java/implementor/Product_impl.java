package implementor;

import db_config.GetConnection;
import model.Product_pojo;
import operation.Product_operation;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Product_impl implements Product_operation {

    @Override
    public String add_product(Product_pojo pojo) {
        String message = "Something went wrong!";
        try (Connection conn = GetConnection.getConnection();
                CallableStatement cs = conn.prepareCall("{CALL seller_add_product(?,?,?,?)}")) {
            cs.setString(1, pojo.getSeller_port_id());
            cs.setString(2, pojo.getProduct_name());
            cs.setDouble(3, pojo.getPrice());
            cs.setInt(4, pojo.getQuantity());
            cs.execute();
            message = "Product added successfully.";
        } catch (SQLException e) {
            e.printStackTrace();
            message = "Error: " + e.getMessage();
        }
        return message;
    }

    @Override
    public String update_product_name(Product_pojo pojo) {
        String message = "Something went wrong!";
        try (CallableStatement cs = GetConnection.getConnection()
                .prepareCall("{CALL seller_update_product_name(?,?,?)}")) {
            cs.setInt(1, pojo.getProduct_id());
            cs.setString(2, pojo.getSeller_port_id());
            cs.setString(3, pojo.getProduct_name());
            cs.execute();
            message = "Product name updated.";
        } catch (SQLException e) {
            e.printStackTrace();
            message = "Error: " + e.getMessage();
        }
        return message;
    }

    @Override
    public String update_product_price(Product_pojo pojo) {
        String message = "Something went wrong!";
        try (CallableStatement cs = GetConnection.getConnection()
                .prepareCall("{CALL seller_update_product_price(?,?,?)}")) {
            cs.setInt(1, pojo.getProduct_id());
            cs.setString(2, pojo.getSeller_port_id());
            cs.setDouble(3, pojo.getPrice());
            cs.execute();
            message = "Product price updated.";
        } catch (SQLException e) {
            e.printStackTrace();
            message = "Error: " + e.getMessage();
        }
        return message;
    }

    @Override
    public String restock_product(Product_pojo pojo) {
        String message = "Something went wrong!";
        try (CallableStatement cs = GetConnection.getConnection()
                .prepareCall("{CALL seller_update_product_quantity(?,?,?)}")) {
            cs.setInt(1, pojo.getProduct_id());
            cs.setString(2, pojo.getSeller_port_id());
            cs.setInt(3, pojo.getQuantity());
            cs.execute();
            message = "Product quantity updated.";
        } catch (SQLException e) {
            e.printStackTrace();
            message = "Error: " + e.getMessage();
        }
        return message;
    }

    @Override
    public String delete_product(Product_pojo pojo) {
        String message = "Something went wrong!";
        try (CallableStatement cs = GetConnection.getConnection().prepareCall("{CALL seller_delete_product(?,?)}")) {
            cs.setInt(1, pojo.getProduct_id());
            cs.setString(2, pojo.getSeller_port_id());
            cs.execute();
            message = "Product deleted.";
        } catch (SQLException e) {
            e.printStackTrace();
            message = "Error: " + e.getMessage();
        }
        return message;
    }

    @Override
    public List<Product_pojo> view_seller_products_with_sales(String sellerid, String search, int limit, int offset) {
        List<Product_pojo> list = new ArrayList<>();
        try (Connection conn = GetConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(
                        "SELECT product_id, product_name, quantity, price, seller_port_id FROM products WHERE seller_port_id = ? AND (LOWER(product_name) LIKE ? OR ? = '') LIMIT ? OFFSET ?")) {
            ps.setString(1, sellerid);
            ps.setString(2, "%" + search.toLowerCase() + "%");
            ps.setString(3, search.trim().isEmpty() ? "" : search.toLowerCase());
            ps.setInt(4, limit);
            ps.setInt(5, offset);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Product_pojo p = new Product_pojo();
                p.setProduct_id(rs.getInt("product_id"));
                p.setProduct_name(rs.getString("product_name"));
                p.setQuantity(rs.getInt("quantity"));
                p.setPrice(rs.getDouble("price"));
                p.setSeller_port_id(rs.getString("seller_port_id"));
                list.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public int getProductCount(String sellerId, String search) {
        int count = 0;
        try (Connection conn = GetConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(
                        "SELECT COUNT(*) FROM products WHERE seller_port_id = ? AND (LOWER(product_name) LIKE ? OR ? = '')")) {
            ps.setString(1, sellerId);
            ps.setString(2, "%" + search.toLowerCase() + "%");
            ps.setString(3, search.trim().isEmpty() ? "" : search.toLowerCase());
            ResultSet rs = ps.executeQuery();
            if (rs.next())
                count = rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }

    @Override
    public Product_pojo getProductById(int productId) {
        Product_pojo p = null;
        try (Connection conn = GetConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement("SELECT * FROM products WHERE product_id = ?")) {
            ps.setInt(1, productId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                p = new Product_pojo();
                p.setProduct_id(rs.getInt("product_id"));
                p.setProduct_name(rs.getString("product_name"));
                p.setQuantity(rs.getInt("quantity"));
                p.setPrice(rs.getDouble("price"));
                p.setSeller_port_id(rs.getString("seller_port_id"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return p;
    }
}
