package implementor;

import java.sql.CallableStatement;
import java.sql.Connection;

import db_config.GetConnection;
import operation.EditProfileOperations;

public class EditProfileImplementor implements EditProfileOperations {
    @Override
    public String editProfile(String portId, String role, String newPassword, String newLocation,
                              boolean updatePassword, boolean updateLocation, boolean deleteAccount) {
        String result = "Profile Updated Successfully";
        try (Connection con = GetConnection.getConnection();
             CallableStatement cs = con.prepareCall("{CALL edit_profile(?, ?, ?, ?, ?, ?, ?)}")) {

            cs.setString(1, portId);
            cs.setString(2, role);
            cs.setString(3, newPassword);
            cs.setString(4, newLocation);
            cs.setBoolean(5, updatePassword);
            cs.setBoolean(6, updateLocation);
            cs.setBoolean(7, deleteAccount);
            cs.execute();

        } catch (Exception e) {
            e.printStackTrace();
            result = "Error: " + e.getMessage();
        }
        return result;
    }
}
