package implementor;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import model.Order_pojo;
import model.Product_pojo;
import operation.Order_operations;
import db_config.GetConnection;

public class Order_Implementor implements Order_operations {

    @Override
    public List<Product_pojo> getAllProducts() {
        List<Product_pojo> products = new ArrayList<>();
        String sql = "SELECT product_id, product_name, quantity, price, seller_port_id FROM products";
        try (Statement stmt = GetConnection.getConnection().createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Product_pojo product = new Product_pojo();
                product.setProduct_id(rs.getInt("product_id"));
                product.setProduct_name(rs.getString("product_name"));
                product.setQuantity(rs.getInt("quantity"));
                product.setPrice(rs.getDouble("price"));
                product.setSeller_port_id(rs.getString("seller_port_id"));
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }

    @Override
    public String placeOrder(int productId, String consumerPortId, int quantity, String sellerPortId,
            String consumerLocation) {
        String message = "";
        try (Connection con = GetConnection.getConnection();
                CallableStatement cs = con.prepareCall("{call order_product(?,?,?,?)}")) {

            cs.setInt(1, productId);
            cs.setString(2, consumerPortId);
            cs.setInt(3, quantity);
            cs.setString(4, sellerPortId);

            cs.execute();
            message = "Order placed successfully!";
        } catch (SQLException e) {
            message = "Error: " + e.getMessage();
            e.printStackTrace();
        }
        return message;
    }

    @Override
    public List<Order_pojo> getAllOrders() {

        List<Order_pojo> orders = new ArrayList<>();
        String sql = "SELECT o.order_id, o.product_id, p.product_name, o.quantity, "
                + "o.consumer_port_id, cp.location, o.order_date, "
                + "o.order_placed, o.shipped, o.out_for_delivery, o.delivered, o.seller_port_id, p.price "
                + "FROM orders o "
                + "JOIN products p ON o.product_id = p.product_id "
                + "LEFT JOIN consumer_port cp ON o.consumer_port_id = cp.port_id";

        try (Statement stmt = GetConnection.getConnection().createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Order_pojo order = extractOrderFromResultSet(rs);
                order.setPrice(rs.getDouble("price"));
                orders.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }

    @Override
    public List<Order_pojo> getAllOrders(String sellerPortId) {
        List<Order_pojo> orders = new ArrayList<>();
        String sql = "SELECT o.order_id, o.product_id, p.product_name, o.quantity, "
                + "o.consumer_port_id, cp.location, o.order_date, "
                + "o.order_placed, o.shipped, o.out_for_delivery, o.delivered, o.seller_port_id, p.price "
                + "FROM orders o "
                + "JOIN products p ON o.product_id = p.product_id "
                + "LEFT JOIN consumer_port cp ON o.consumer_port_id = cp.port_id "
                + "WHERE o.seller_port_id = ?";

        try (Connection con = GetConnection.getConnection();
                PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setString(1, sellerPortId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Order_pojo order = extractOrderFromResultSet(rs);
                order.setPrice(rs.getDouble("price"));
                orders.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }

    private Order_pojo extractOrderFromResultSet(ResultSet rs) throws SQLException {
        Order_pojo order = new Order_pojo();
        order.setOrderId(rs.getInt("order_id"));
        order.setProductId(rs.getInt("product_id"));
        order.setProductName(rs.getString("product_name"));
        order.setQuantity(rs.getInt("quantity"));
        order.setConsumerPortId(rs.getString("consumer_port_id"));
        order.setConsumerPortLocation(rs.getString("location"));
        order.setOrderDate(rs.getDate("order_date"));
        order.setSellerPortId(rs.getString("seller_port_id"));
        order.setPrice(rs.getDouble("price"));

        String status;
        if (rs.getBoolean("delivered")) {
            status = "Delivered";
        } else if (rs.getBoolean("out_for_delivery")) {
            status = "Out for Delivery";
        } else if (rs.getBoolean("shipped")) {
            status = "Shipped";
        } else if (rs.getBoolean("order_placed")) {
            status = "Pending";
        } else {
            status = "Pending";
        }
        order.setStatus(status);

        return order;
    }

    @Override
    public String updateOrderQuantityWithInventory(int orderId, int newQuantity) {
        try (Connection con = GetConnection.getConnection()) {
            con.setAutoCommit(false);

            PreparedStatement getOrderStmt = con.prepareStatement(
                    "SELECT product_id, quantity FROM orders WHERE order_id = ?");
            getOrderStmt.setInt(1, orderId);
            ResultSet rs = getOrderStmt.executeQuery();

            if (!rs.next())
                return "Error: Order not found.";

            int productId = rs.getInt("product_id");
            int oldQuantity = rs.getInt("quantity");
            int diff = newQuantity - oldQuantity;

            if (diff > 0) {
                PreparedStatement checkStock = con.prepareStatement(
                        "SELECT quantity FROM products WHERE product_id = ?");
                checkStock.setInt(1, productId);
                ResultSet stockRs = checkStock.executeQuery();
                if (stockRs.next() && stockRs.getInt("quantity") < diff) {
                    return "Error: Not enough stock available.";
                }
                checkStock.close();
            }

            PreparedStatement updateOrder = con.prepareStatement(
                    "UPDATE orders SET quantity = ? WHERE order_id = ?");
            updateOrder.setInt(1, newQuantity);
            updateOrder.setInt(2, orderId);
            updateOrder.executeUpdate();

            PreparedStatement updateStock = con.prepareStatement(
                    "UPDATE products SET quantity = quantity - ? WHERE product_id = ?");
            updateStock.setInt(1, diff);
            updateStock.setInt(2, productId);
            updateStock.executeUpdate();

            con.commit();
            return "Order quantity updated successfully.";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Error: " + e.getMessage();
        }
    }

    @Override
    public String updateOrderConsumer(int orderId, String newConsumerPortId) {
        try (CallableStatement stmt = GetConnection.getConnection().prepareCall("{ call UpdateOrderConsumer(?, ?) }")) {
            stmt.setInt(1, orderId);
            stmt.setString(2, newConsumerPortId);
            stmt.execute();
            return "Order consumer updated successfully.";
        } catch (SQLException e) {
            return "Error: " + e.getMessage();
        }
    }

    @Override
    public String updateConsumerLocation(String consumerPortId, String newLocation) {
        try (CallableStatement stmt = GetConnection.getConnection()
                .prepareCall("{ call UpdateConsumerLocation(?, ?) }")) {
            stmt.setString(1, consumerPortId);
            stmt.setString(2, newLocation);
            stmt.execute();
            return "Consumer location updated successfully.";
        } catch (SQLException e) {
            return "Error: " + e.getMessage();
        }
    }

    @Override
    public String deleteOrder(int orderId) {
        try (CallableStatement stmt = GetConnection.getConnection().prepareCall("{ call DeleteOrder(?) }")) {
            stmt.setInt(1, orderId);
            stmt.execute();
            return "Order deleted successfully.";
        } catch (SQLException e) {
            return "Error: " + e.getMessage();
        }
    }

    @Override
    public Order_pojo getOrderById(int orderId) {
        try (PreparedStatement stmt = GetConnection.getConnection().prepareStatement(
                "SELECT order_id, product_id, quantity FROM orders WHERE order_id = ?")) {
            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Order_pojo order = new Order_pojo();
                order.setOrderId(rs.getInt("order_id"));
                order.setProductId(rs.getInt("product_id"));
                order.setQuantity(rs.getInt("quantity"));
                return order;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public String incrementProductQuantity(int productId, int quantity) {
        try (PreparedStatement stmt = GetConnection.getConnection().prepareStatement(
                "UPDATE products SET quantity = quantity + ? WHERE product_id = ?")) {
            stmt.setInt(1, quantity);
            stmt.setInt(2, productId);
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                return "Product quantity incremented successfully.";
            } else {
                return "Error: Product not found.";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return "Error: " + e.getMessage();
        }
    }

    @Override
    public String updateOrderQuantity(int orderId, int newQuantity) {
        // unused for now
        return null;
    }

    @Override
    public List<Product_pojo> getProductsPaginated(int offset, int limit) {
        List<Product_pojo> products = new ArrayList<>();
        String sql = "SELECT product_id, product_name, quantity, price, seller_port_id FROM products LIMIT ? OFFSET ?";
        try (PreparedStatement stmt = GetConnection.getConnection().prepareStatement(sql)) {
            stmt.setInt(1, limit);
            stmt.setInt(2, offset);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Product_pojo product = new Product_pojo();
                product.setProduct_id(rs.getInt("product_id"));
                product.setProduct_name(rs.getString("product_name"));
                product.setQuantity(rs.getInt("quantity"));
                product.setPrice(rs.getDouble("price"));
                product.setSeller_port_id(rs.getString("seller_port_id"));
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }

    @Override
    public int getProductsCount() {
        String sql = "SELECT COUNT(*) FROM products";
        try (Statement stmt = GetConnection.getConnection().createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next())
                return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public List<Order_pojo> getOrdersByConsumer(String consumerPortId) {
        List<Order_pojo> orders = new ArrayList<>();
        String sql = "SELECT o.order_id, o.product_id, p.product_name, o.quantity, o.order_date, o.order_placed, o.shipped, o.out_for_delivery, o.delivered, o.seller_port_id, p.price FROM orders o JOIN products p ON o.product_id = p.product_id WHERE o.consumer_port_id = ?";
        try (Connection con = GetConnection.getConnection();
                PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, consumerPortId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Order_pojo order = extractOrderFromResultSet(rs);
                orders.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }

    @Override
    public Order_pojo getOrderStatus(int orderId) {
        try (Connection con = GetConnection.getConnection();
                CallableStatement cs = con.prepareCall("{call get_order_status(?)}")) {
            cs.setInt(1, orderId);
            ResultSet rs = cs.executeQuery();
            if (rs.next()) {
                Order_pojo status = new Order_pojo();
                status.setOrderId(rs.getInt("order_id"));
                status.setProductId(rs.getInt("product_id"));
                status.setProductName(rs.getString("product_name"));
                status.setQuantity(rs.getInt("quantity"));
                status.setConsumerPortId(rs.getString("consumer_port_id"));
                status.setConsumerPortLocation(rs.getString("consumer_port_location"));
                status.setOrderDate(rs.getDate("order_date"));
                status.setOrderPlaced(rs.getBoolean("order_placed"));
                status.setShipped(rs.getBoolean("shipped"));
                status.setOutForDelivery(rs.getBoolean("out_for_delivery"));
                status.setDelivered(rs.getBoolean("delivered"));
                status.setSellerPortId(rs.getString("seller_port_id"));
                // Add more fields if needed
                return status;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public String updateOrderFlag(int orderId, String stage) {
        try (Connection con = GetConnection.getConnection();
                CallableStatement cs = con.prepareCall("{call update_order_flag(?, ?)}")) {
            cs.setInt(1, orderId);
            cs.setString(2, stage);
            cs.execute();
            return "Order status updated!";
        } catch (SQLException e) {
            return "Error: " + e.getMessage();
        }
    }

    @Override
    public List<Order_pojo> getSellerOrdersPaginated(String sellerPortId, int offset, int limit) {
        List<Order_pojo> orders = new ArrayList<>();
        String sql = "SELECT o.order_id, o.product_id, p.product_name, o.quantity, o.consumer_port_id, o.order_date, o.order_placed, o.shipped, o.out_for_delivery, o.delivered, p.price "
                + "FROM orders o JOIN products p ON o.product_id = p.product_id "
                + "WHERE o.seller_port_id = ? LIMIT ? OFFSET ?";
        try (Connection con = GetConnection.getConnection();
                PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, sellerPortId);
            stmt.setInt(2, limit);
            stmt.setInt(3, offset);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Order_pojo order = new Order_pojo();
                order.setOrderId(rs.getInt("order_id"));
                order.setProductId(rs.getInt("product_id"));
                order.setProductName(rs.getString("product_name"));
                order.setQuantity(rs.getInt("quantity"));
                order.setConsumerPortId(rs.getString("consumer_port_id"));
                order.setOrderDate(rs.getDate("order_date"));
                order.setOrderPlaced(rs.getBoolean("order_placed"));
                order.setShipped(rs.getBoolean("shipped"));
                order.setOutForDelivery(rs.getBoolean("out_for_delivery"));
                order.setDelivered(rs.getBoolean("delivered"));
                order.setPrice(rs.getDouble("price"));

                // Set status
                String status;
                if (rs.getBoolean("delivered")) {
                    status = "Delivered";
                } else if (rs.getBoolean("out_for_delivery")) {
                    status = "Out for Delivery";
                } else if (rs.getBoolean("shipped")) {
                    status = "Shipped";
                } else if (rs.getBoolean("order_placed")) {
                    status = "Pending";
                } else {
                    status = "Pending";
                }
                order.setStatus(status);

                orders.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }

    @Override
    public int getSellerOrdersCount(String sellerPortId) {
        String sql = "SELECT COUNT(*) FROM orders o JOIN products p ON o.product_id = p.product_id WHERE o.seller_port_id = ?";
        try (Connection con = GetConnection.getConnection();
                PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, sellerPortId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next())
                return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public List<Order_pojo> getConsumerOrdersPaginated(String consumerPortId, int offset, int limit) {
        List<Order_pojo> orders = new ArrayList<>();
        String sql = "SELECT o.order_id, o.product_id, p.product_name, o.quantity, o.order_date, o.order_placed, o.shipped, o.out_for_delivery, o.delivered, o.seller_port_id, o.consumer_port_id AS consumer_port_id, cp.location, p.price FROM orders o JOIN products p ON o.product_id = p.product_id LEFT JOIN consumer_port cp ON o.consumer_port_id = cp.port_id WHERE o.consumer_port_id = ? LIMIT ? OFFSET ?";
        try (Connection con = GetConnection.getConnection();
                PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, consumerPortId);
            stmt.setInt(2, limit);
            stmt.setInt(3, offset);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Order_pojo order = extractOrderFromResultSet(rs);
                orders.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }

    @Override
    public int getConsumerOrdersCount(String consumerPortId) {
        String sql = "SELECT COUNT(*) FROM orders o JOIN products p ON o.product_id = p.product_id WHERE o.consumer_port_id = ?";
        try (Connection con = GetConnection.getConnection();
                PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, consumerPortId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next())
                return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}
