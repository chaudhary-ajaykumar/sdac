package controller;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;

import db_config.GetConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/editProfile")
public class EditProfileServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String portId = request.getParameter("port_id");
        String role = request.getParameter("role");
        String newPassword = request.getParameter("new_password");
        String newLocation = request.getParameter("new_location");
        boolean deleteAccount = request.getParameter("delete_account") != null;

        boolean updatePassword = newPassword != null && !newPassword.trim().isEmpty();
        boolean updateLocation = newLocation != null && !newLocation.trim().isEmpty();

        String message = "";
        if (!updatePassword && !updateLocation && !deleteAccount) {
            message = "No changes made!";
        } else {
            message = editProfile(portId, role, newPassword, newLocation, updatePassword, updateLocation,
                    deleteAccount);
        }

        request.setAttribute("message", message);
        request.getRequestDispatcher("edit_profile.jsp").forward(request, response);
    }

    public String editProfile(String portId, String role, String newPassword, String newLocation,
            boolean updatePassword, boolean updateLocation, boolean deleteAccount) {
        String message = "";
        try (Connection conn = GetConnection.getConnection();
                CallableStatement stmt = conn.prepareCall("{CALL edit_profile(?, ?, ?, ?, ?, ?, ?)}")) {

            stmt.setString(1, portId);
            stmt.setString(2, role);
            stmt.setString(3, newPassword != null ? newPassword : "");
            stmt.setString(4, newLocation != null ? newLocation : "");
            stmt.setBoolean(5, updatePassword);
            stmt.setBoolean(6, updateLocation);
            stmt.setBoolean(7, deleteAccount);
            stmt.execute();

            if (deleteAccount)
                message = "Profile Deleted Successfully!";
            else if (updatePassword || updateLocation)
                message = "Profile Updated Successfully!";
            else
                message = "No changes made!";

        } catch (Exception e) {
            e.printStackTrace();
            message = "An error occurred: " + e.getMessage();
        }
        return message;
    }
}
