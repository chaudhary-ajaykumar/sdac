package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

import db_config.GetConnection;

@WebServlet("/UserController")
public class UserController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Always treat as login if no action param (for login.jsp)
        String action = request.getParameter("action");
        if (action == null || "login".equals(action)) {
            loginUser(request, response);
        } else if ("register".equals(action)) {
            registerUser(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Agar user already logged in hai toh dashboard pe redirect karo
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("port_id") != null) {
            response.sendRedirect("dashboard.jsp");
        } else {
            // Nahi toh login page dikhao
            response.sendRedirect("login.jsp");
        }
    }

    private void registerUser(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        String portId = request.getParameter("port_id");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirm_password");
        String location = request.getParameter("location");
        String role = request.getParameter("role");

        try (Connection con = GetConnection.getConnection()) {
            CallableStatement stmt = con.prepareCall("{CALL register_user(?, ?, ?, ?, ?)}");
            stmt.setString(1, portId);
            stmt.setString(2, password);
            stmt.setString(3, confirmPassword);
            stmt.setString(4, location);
            stmt.setString(5, role);
            stmt.execute();
            request.setAttribute("message", "Registration successful. Please login.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        } catch (SQLException e) {
            request.setAttribute("message", e.getMessage());
            request.getRequestDispatcher("register.jsp").forward(request, response);
        }
    }

    private void loginUser(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        String portId = request.getParameter("port_id");
        String password = request.getParameter("password");
        String role = request.getParameter("role");

        try (Connection con = GetConnection.getConnection()) {
            CallableStatement stmt = con.prepareCall("{? = CALL verify_login(?, ?, ?)}");
            stmt.registerOutParameter(1, Types.VARCHAR);
            stmt.setString(2, portId);
            stmt.setString(3, password);
            stmt.setString(4, role);
            stmt.execute();

            String message = stmt.getString(1);

            if (message.contains("Success")) {
                // Invalidate old session
                HttpSession oldSession = request.getSession(false);
                if (oldSession != null)
                    oldSession.invalidate();

                // Create new session
                HttpSession session = request.getSession(true);
                session.setAttribute("port_id", portId);
                session.setAttribute("role", role);
                session.setAttribute("isSeller", "Seller".equalsIgnoreCase(role));
                System.out.println("LOGIN DEBUG: port_id=" + portId + ", role=" + role);
                response.sendRedirect("dashboard.jsp");
            } else {
                request.setAttribute("message", message);
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            request.setAttribute("message", e.getMessage());
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}
