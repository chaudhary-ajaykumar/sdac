package controller;

import implementor.SalesImplementor;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import model.SalesPojo;

import java.io.IOException;
import java.time.Year;
import java.util.List;

@WebServlet("/salesAnalysis")
public class SalesAnalysisServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // SellerId session se lo
        HttpSession session = request.getSession();
        String sellerId = (String) session.getAttribute("port_id");
        if (sellerId == null || sellerId.trim().isEmpty()) {
            response.sendRedirect("login.jsp");
            return;
        }

        String yearParam = request.getParameter("year");
        int year;
        if (yearParam != null && !yearParam.trim().isEmpty()) {
            try {
                year = Integer.parseInt(yearParam.trim());
            } catch (NumberFormatException e) {
                year = java.time.Year.now().getValue();
            }
        } else {
            year = java.time.Year.now().getValue();
        }

        SalesImplementor si = new SalesImplementor();

        // Always fetch these for cards
        int totalOrders = si.getTotalOrders(sellerId);
        int pendingOrders = si.getPendingOrders(sellerId);
        double totalRevenue = si.getTotalRevenue(sellerId);
        List<SalesPojo> monthly = si.getMonthlySales(sellerId, year);
        List<SalesPojo> annual = si.getAnnualSales(sellerId);

        request.setAttribute("totalOrders", totalOrders);
        request.setAttribute("pendingOrders", pendingOrders);
        request.setAttribute("totalRevenue", totalRevenue);
        request.setAttribute("monthlySales", monthly);
        request.setAttribute("annualSales", annual);

        request.getRequestDispatcher("sales.jsp").forward(request, response);
    }
}
