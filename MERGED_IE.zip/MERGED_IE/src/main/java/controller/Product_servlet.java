package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import model.Product_pojo;
import implementor.Product_impl;

import java.io.IOException;
import java.util.List;

@WebServlet(urlPatterns = { "/productList", "/addProduct", "/editProduct", "/deleteProduct" })
public class Product_servlet extends HttpServlet {
    private static final String ACTION_LIST = "/productList";
    private static final String ACTION_ADD = "/addProduct";
    private static final String ACTION_EDIT = "/editProduct";
    private static final String ACTION_DELETE = "/deleteProduct";

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getServletPath();

        if (action.equals(ACTION_LIST)) {
            String sellerId = (String) request.getSession().getAttribute("port_id");
            if (sellerId == null || sellerId.trim().isEmpty()) {
                response.sendRedirect("login.jsp");
                return;
            }

            String search = request.getParameter("search") != null ? request.getParameter("search") : "";
            int page = request.getParameter("page") != null ? Integer.parseInt(request.getParameter("page")) : 1;
            int offset = (page - 1) * 10;

            List<Product_pojo> products = new Product_impl().view_seller_products_with_sales(sellerId, search, 10,
                    offset);
            int totalRecords = new Product_impl().getProductCount(sellerId, search);
            int totalPages = (int) Math.ceil(totalRecords * 1.0 / 10);

            request.setAttribute("products", products);
            request.setAttribute("totalPages", totalPages);
            request.setAttribute("currentPage", page);
            request.getRequestDispatcher("product_list.jsp").forward(request, response);
        } else if (action.equals(ACTION_EDIT)) {
            int productId = Integer.parseInt(request.getParameter("id"));
            Product_pojo product = new Product_impl().getProductById(productId);
            request.setAttribute("product", product);
            request.getRequestDispatcher("edit_product.jsp").forward(request, response);
        } else if (action.equals(ACTION_DELETE)) {
            int productId = Integer.parseInt(request.getParameter("id"));
            String sellerId = (String) request.getSession().getAttribute("port_id");
            Product_pojo pojo = new Product_pojo();
            pojo.setProduct_id(productId);
            pojo.setSeller_port_id(sellerId);
            String msg = new Product_impl().delete_product(pojo);
            request.getSession().setAttribute("message", msg);
            response.sendRedirect("productList");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getServletPath();

        if (action.equals(ACTION_ADD)) {
            String name = request.getParameter("product_name");
            int qty = Integer.parseInt(request.getParameter("quantity"));
            double price = Double.parseDouble(request.getParameter("product_price"));

            String sellerId = (String) request.getSession().getAttribute("port_id");
            if (sellerId == null || sellerId.trim().isEmpty()) {
                response.sendRedirect("login.jsp");
                return;
            }

            Product_pojo pojo = new Product_pojo();
            pojo.setProduct_name(name);
            pojo.setQuantity(qty);
            pojo.setPrice(price);
            pojo.setSeller_port_id(sellerId);

            String msg = new Product_impl().add_product(pojo);
            request.getSession().setAttribute("message", msg);
            response.sendRedirect("productList");
        } else if (action.equals(ACTION_EDIT)) {
            int id = Integer.parseInt(request.getParameter("product_id"));
            String sellerId = (String) request.getSession().getAttribute("port_id");
            Product_pojo oldProduct = new Product_impl().getProductById(id);

            String newName = request.getParameter("product_name");
            int newQty = Integer.parseInt(request.getParameter("quantity"));
            double newPrice = Double.parseDouble(request.getParameter("product_price"));

            Product_pojo pojo = new Product_pojo();
            pojo.setProduct_id(id);
            pojo.setSeller_port_id(sellerId);

            StringBuilder msg = new StringBuilder();

            if (!oldProduct.getProduct_name().equals(newName)) {
                pojo.setProduct_name(newName);
                msg.append(new Product_impl().update_product_name(pojo)).append(" ");
            }

            if (oldProduct.getPrice() != newPrice) {
                pojo.setPrice(newPrice);
                msg.append(new Product_impl().update_product_price(pojo)).append(" ");
            }

            if (oldProduct.getQuantity() != newQty) {
                pojo.setQuantity(newQty);
                msg.append(new Product_impl().restock_product(pojo)).append(" ");
            }

            request.getSession().setAttribute("message", msg.toString().trim());
            response.sendRedirect("productList");
        }
    }
}
