package operation;

import java.util.List;
import model.SalesPojo;

public interface SalesOperations {
    List<SalesPojo> getMonthlySales(String sellerId, int year);

    List<SalesPojo> getAnnualSales(String sellerId);

    double getTotalRevenue(String sellerId);

    int getTotalOrders(String sellerId);

    int getPendingOrders(String sellerId);
}
