package operation;

import java.util.List;
import model.Product_pojo;

public interface Product_operation {
    String add_product(Product_pojo pojo);

    String update_product_name(Product_pojo pojo);

    String update_product_price(Product_pojo pojo);

    String restock_product(Product_pojo pojo);

    String delete_product(Product_pojo pojo);

    List<Product_pojo> view_seller_products_with_sales(String sellerid, String search, int limit, int offset);

    int getProductCount(String sellerId, String search);

    Product_pojo getProductById(int productId);
}
